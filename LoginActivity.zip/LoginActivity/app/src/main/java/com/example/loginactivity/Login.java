package com.example.loginactivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.loginactivity.databinding.ActivityLoginBinding;
import com.example.loginactivity.network.Api;
import com.example.loginactivity.network.AppConfig;
import com.example.loginactivity.network.ServerResponse;
import com.example.loginactivity.utils.Config;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class Login extends AppCompatActivity {

    private ActivityLoginBinding binding;
    private Context context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);



        binding.loginbtn.setOnClickListener(v -> {
            String Email = binding.email.getText().toString();
            String Password = binding.password.getText().toString();


            if (TextUtils.isEmpty(Email) || TextUtils.isEmpty(Password)) {
                binding.email.setError("All fields are required !!");
                binding.password.setError("All fields are required!!");
                return;
            }
            Log.v("Login ","It Works");

            doLogin(Email,Password);

        });

        binding.registerbtn.setOnClickListener(v -> {
            Intent obj = new Intent(Login.this, Register.class);
            Login.this.startActivity(obj);

        });

    }

    private void doLogin(String email, String password) {
        Retrofit retrofit = AppConfig.getRetrofit();
        Api service = retrofit.create(Api.class);

        Call<ServerResponse> call = service.login(email, password);
        call.enqueue(new Callback<ServerResponse>() {
            @Override
            public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {

                if(response.body()!=null){

                    ServerResponse serverResponse = response.body();

                    if(!serverResponse.getError()){
                        Config.showToast(context,serverResponse.getMessage());
                        Intent obj = new Intent(Login.this, Home.class);
                        startActivity(obj);

                    }
                    else {
                        Config.showToast(context,serverResponse.getMessage());

                    }
                }
            }

            @Override
            public void onFailure(Call<ServerResponse> call, Throwable t) {
                Config.showToast(context, t.getMessage());
            }
        });

    }
}